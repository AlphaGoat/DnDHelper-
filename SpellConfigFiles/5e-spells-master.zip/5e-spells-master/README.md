This is a hopefully complete and mostly correct database of D&D 5e spells in a computer
readable format.

It may be a bit off in some places, as it was created by copypasting the list from the
Basic Rules PDF, cleaning it up a bit manually and lazily parsing it line-by-line.
The result is in spells.json, if you wish to generate it yourself you'll need a Perl 6
compiler with JSON::Tiny installed.

Please report any issues and discrepancies with the original list (I know that tables either
aren't there at all or are completely wrong), and I'll try to fix them.

I'm not sure if Basic Rules license allows that (not too good at lawyerspeak), but if you
Wizards are reading this, I'll happily comply to any DMCA takedown or whatever.

Enjoy!
